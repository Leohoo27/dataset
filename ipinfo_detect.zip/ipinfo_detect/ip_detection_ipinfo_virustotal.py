# -*- coding: utf-8 -*-
'''
Leveraging ipinfo.io to access ip address info, and save in json file
Leveraging VirusTotal api to access ip address info, and save in json file
Usage: python3 ip_detection_ipinfo_virustotal.py --detector ipinfo --threads 8 \
--under_detect_ip_file /home/lihao/work/storj/ip_address_analysis/20210303/new_ip_upload_0304.csv \
--already_detected_file /home/lihao/work/storj/ip_address_analysis/20210303/virustotal/virustotal_reports_upload_0302.json
'''
import argparse
import sys
import os
import pandas as pd
import ipinfo
import json
import threading
from queue import Queue
import random
import subprocess
import logging
import time

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(message)s')

exitFlag = 0
apikey_list = [
    'bb05cf5d129ce9b481f1e560e41f23583545d4df8da74eb22135570f67cb49f4',
    '18ab782d455b8d23f07a8078541ecc3eef98393ae058a537745099cf834470a7',
    'cbb26e5bd94c5015ff7b56f05238b1f09f125446b9abea2670d8d79cf2de0716',
    '2b0c81088cb5dddaa39ed1ee89501a8ef5c78094c43bce8af2a6a1f1195bdd32',
    'e844ccf3f976e43ff1dc3a654524f766c8484cc50956166cb0ba9ad37419c5e8',
    '446d95f73c35953182f64ee7a175bd815d325a16ab309af4cd872c32143ef9f6',
    '296fce984842865aac08e41c83a4c2866435ef15e19f49939e00a71b60e20b94',
    '8e3c23e71d1d8c7f5e5b866274b496a58f7668e3bf0495087cbaf39c06ec6cc4',
    '2ee8fa0b26c03eb19536505bb8b854b287da0acdd9af785e86e9f083455772ae',
    '4799f13d31cb339eee8cdeff230c07d673d26b26d2de28cdff46f524ce8f7a91',
    '0abcd1eaa826bb481e728194c512e708d08f0ea74fcb212f1e13f36f41e3df2e',
    'ae8292c63397b55395fa9d2428fdeb1ddf438da93eacf9b8709e8b18bd8fc36a',
    '58f268fde2c085aa09f15a224f3e78f8ba48aff863bac3c51c32d18352bc521d',
    '132ac3e63cd2ccc217e604fe866c48caad00f93d1cba4fa36a73ca833da72d2e',
    '6c3765ff49d347e9e7a401e33e440638977ec0f1e1ad636202184e3edafdd611',
    '6303e7f9083e819a2b5b52c805401710c49519f354eaaa27b0bef2e25b108237',
    'd82ab6d79da3d6273f4d4e7549e5589d2c95c349aa053fb6c8e5b4ef27859a32',
    '5a840e3d69b992498d4776643799bf21bffb1b11cfd17c1d633b9ad2834a38db',
    'fffef29c3f11707e0387aa0ad9fb8bc17efb5208904f9242cf3a46974fc24757',
    '5f416a761f4abc5621027920c744c9395e0b0b7b7df9f59b39d4562bd0ba5838',
    '125b25ebdcab3cd47a951593776ae1054d39518baca97502d72673c70505638c',
    'a47f0973e8888144476d94abf1d645e93ec8bba1fc352143fe5568427bdb4a13',
    '9b480323cc5fcb62c6174d93aa6deae0eae3700ee60aca25aa7d307bb4b72fd4',
    'fcd46b27960be3406e0c0afdf2a5338619dba4a139bf9238a931be37ffd6ecd7',
    'afd41e707f9b7292c70fb90d69aee6fd8e8703463c6c89fda7cf64b0be45a17d',
    'fa6443d30c40aed12b6befb93559a6f1ec51b8fcc947acdc1094f472482d0a73',
    'e3a99099623f90d4ed5301c7784cf9ea66b412c533ec730cb2b754c33a11f87d',
    'af5e87c4a60bfaa48c27d34d428355caf6def34f1bc8bae48df026ef50d637d5',
    '080557549e6477fd160bdc3994ea3927702efdf266c0ddcc633103f796a49767',
    'ea68e8e106772626ea2164706990b7245f19b1dfcddaac8508e245a4dadae3b7',
    '218ce8c23abd6e0f76f8a15b03e0e0920397e01d9fc67c5dfd3fd3c9f7f1ec73',
    '5a047e064dd9a8e804c7737e09c882d10a1764db930f829a3c58ab063a819d24',
]


class myThread(threading.Thread):
    def __init__(self, threadID, name, q):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.q = q

    def run(self):
        logging.info("开启线程：" + self.name)
        self.process_data(self.name, self.q)
        logging.info("退出线程：" + self.name)

    def process_data(self, threadName, q):
        while not exitFlag:
            queueLock.acquire()
            if not workQueue.empty():
                data = q.get()
                queueLock.release()

                if args.detector == 'ipinfo':
                    ipinfo_detector = IpInfo()
                    logging.info("%s processing %s" % (threadName, data))
                    ipinfo_detector.ipinfo_detection(q, data)
                elif args.detector == 'virustotal':
                    virustotal_detector = VirusTotal()
                    logging.info("%s processing %s" % (threadName, data))
                    virustotal_detector.virustotal_detection(q, data)
            else:
                queueLock.release()


class IpInfo(object):
    def __init__(self):
        self.access_token = '4e225e7d815b79'

        self.already_detected_ip_list = list()
        self.under_detect_ip_list = list()

    def ipinfo_detection(self, q, ip_address):
        """Detect ip address by ipinfo.io"""
        with open(args.already_detected_file, 'a', encoding='utf-8') as file:
            handler = ipinfo.getHandler(self.access_token, request_options={'timeout': 10},
                                        cache_options={'ttl': 30, 'maxsize': 128})
            try:
                details = handler.getDetails(ip_address)
                logging.info('success detection in {0}!'.format(ip_address))
                json.dump(details.all, file)
                file.write('\n')

            except Exception as e:
                logging.error("{} in {}".format(ip_address, e))
                q.put(ip_address)

    def get_under_detect_ip(self):
        '''
        get unique under detect ip address
        :return: under_detect_ip_set
        '''
        with open(args.already_detected_file) as file:
            for line_item in file.readlines():
                line_item_dict = json.loads(line_item.strip())
                if 'ip' in line_item_dict.keys():
                    self.already_detected_ip_list.append(line_item_dict['ip'])

        already_detected_ip_set = set(self.already_detected_ip_list)

        df = pd.read_csv(args.under_detect_file, header=None).to_numpy()
        self.under_detect_ip_list = df[:, 0]

        under_detect_ip_set = set(self.under_detect_ip_list) - (
                set(self.under_detect_ip_list) & already_detected_ip_set)

        logging.warning("number of under detect ip set: {}".format(len(under_detect_ip_set)))
        return under_detect_ip_set


class VirusTotal(object):
    def __init__(self):

        self.already_detected_item_list = list()
        self.under_detect_item_list = list()

    def get_under_detect_item(self):
        '''
        get unique under detect ip address
        :return: under_detect_ip_set
        '''
        with open(args.already_detected_file) as file:
            for line_item in file.readlines():
                try:
                    line_item_dict = json.loads(line_item.strip())
                except Exception as e:
                    logging.info(e)
                    continue

                if 'id' in line_item_dict['data'].keys():
                    self.already_detected_item_list.append(line_item_dict['data']['id'])

        already_detected_item_set = set(self.already_detected_item_list)

        df = pd.read_csv(args.under_detect_file, header=None).to_numpy()
        self.under_detect_item_list = df[:, 0]

        under_detect_item_set = set(self.under_detect_item_list) - (
                set(self.under_detect_item_list) & already_detected_item_set)

        logging.warning("number of under detect file set: {}".format(len(under_detect_item_set)))

        return under_detect_item_set

    def virustotal_detection(self, q, data):
        """Detect ip address by VirusTotal.com"""
        with open(args.already_detected_file, 'a', encoding='utf-8') as file:
            apikey = random.choice(apikey_list)

            if args.type == 'ip':
                cmd = "curl --request GET --url https://www.virustotal.com/api/v3/ip_addresses/{ip} --header 'x-apikey: {apikey}'".format(
                    ip=data, apikey=apikey
                )

            elif args.type == 'domain':
                cmd = "curl --request GET --url https://www.virustotal.com/api/v3/domains/{id} --header 'x-apikey: {apikey}'".format(
                    id=data, apikey=apikey)

            try:
                p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                vt_out, err = p.communicate()

                if list(json.loads(vt_out).keys())[0] == 'error':
                    ''' if virustotal.com detection error '''
                    q.put(data)  # 加入error元素
                    logging.error('error in {0} VirusTotal api connection! {1} undetected item left!'.format(data, q.qsize()))
                    time.sleep(1)

                else:
                    ''' if VirusTotal.com detection success '''
                    logging.info('success in {0} detection, {1} undetected item left.'.format(data, q.qsize()))
                    json.dump(json.loads(vt_out), file)
                    file.write('\n')

            except Exception as e:
                q.put(data)
                logging.error(e)
                time.sleep(1)


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='IpInfo/VirusTotal detector')
    parser.add_argument('--detector', default='virustotal',
                        help='choose your detection detector (ipinfo or virustotal)')

    parser.add_argument('--threads', default=8, type=int, help='number of process threats')

    parser.add_argument('--under_detect_file',
                        default='./20210317/us_upload_storage_node_IPs.csv',
                        help='under detected file')

    parser.add_argument('--already_detected_file',
                        default='./virustotal_ip_reports.json',
                        help='already detected file')

    parser.add_argument('--type', default='ip', help='ip or domain')

    args = parser.parse_args()

    under_detect_file = args.under_detect_file
    if not os.path.isfile(under_detect_file):
        logging.error('"{}" does not exist'.format(under_detect_file))
        sys.exit(-1)

    threadList = ["Thread-{}".format(str(i)) for i in range(args.threads)]
    queueLock = threading.Lock()
    workQueue = Queue(maxsize=999999)
    threads = []
    threadID = 1

    # 创建新线程
    for tName in threadList:
        thread = myThread(threadID, tName, workQueue)
        thread.start()
        threads.append(thread)
        threadID += 1

    if args.detector == 'ipinfo':
        detector_ipinfo = IpInfo()
        under_detect_set = detector_ipinfo.get_under_detect_ip()

    elif args.detector == 'virustotal':
        detector_virustotal = VirusTotal()
        under_detect_set = detector_virustotal.get_under_detect_item()

    else:
        logging.error('Please check your detector (ipinfo/virustotal)')
        sys.exit(0)

    # 填充队列
    queueLock.acquire()
    for item in under_detect_set:
        workQueue.put(item)
    queueLock.release()

    # 等待队列清空
    while not workQueue.empty():
        pass

    # 通知线程是时候退出
    exitFlag = 1

    # 等待所有线程完成
    for t in threads:
        t.join()
    logging.info("*** detection done! ***, 退出主线程")

    sys.exit(0)
